from django.apps import AppConfig


class FakenewsMlModelsConfig(AppConfig):
    name = 'fakenews_ml_models'
