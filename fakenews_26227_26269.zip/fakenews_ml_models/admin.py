from django.contrib import admin

# Register your models here.
from .models import URLlist

admin.site.register(URLlist)
